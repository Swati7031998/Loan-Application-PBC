export class Transaction{
    id:number;
    account_number:number;
    transaction:String;
}