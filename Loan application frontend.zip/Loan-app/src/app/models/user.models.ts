export class User{
    account_number:number;
    name:string;
    username: string;
    password: string;
    phonenumber: number;
    balance:number;
    emailid: string;
    loan_amount:number;
    asset:number;
    emi:number;
}