import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { ApplyLoanComponent } from './components/apply-loan/apply-loan.component';
import { CheckComponent } from './components/check/check.component';
import { PayEmiComponent } from './components/pay-emi/pay-emi.component';
import { ForecloseComponent } from './components/foreclose/foreclose.component';
import { CalculateEmiComponent } from './components/calculate-emi/calculate-emi.component';
import { PrintComponent } from './components/print/print.component';
import { DepositComponent } from './components/deposit/deposit.component';
import { AboutComponent } from './components/about/about.component';
import { ContactComponent } from './components/contact/contact.component';
import { TransactionsComponent } from './components/transactions/transactions.component';
import { ProfileComponent } from './components/profile/profile.component';
import { ListServicesComponent } from './components/list-services/list-services.component';
import { SignUpComponent } from './components/sign-up/sign-up.component';
import { PayEmi2Component } from './components/pay-emi2/pay-emi2.component';


const routes: Routes = [
{path:'', component:LoginComponent},
{path:'login', component:LoginComponent},
{path:'apply-loan',component:ApplyLoanComponent},
{path:'check',component:CheckComponent},
{path:'pay-emi',component:PayEmiComponent},
{path:'foreclose',component:ForecloseComponent},
{path:'calculate-emi',component:CalculateEmiComponent},
{path:'print',component:PrintComponent},
{path:'deposit',component:DepositComponent},
{path:'about',component:AboutComponent},
{path:'contact',component:ContactComponent},
{path:'transactions',component:TransactionsComponent},
{path:'profile',component:ProfileComponent},
{path:'list-services',component:ListServicesComponent},
{path:'sign-up',component:SignUpComponent},
{path:'pay-emi2',component:PayEmi2Component},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
