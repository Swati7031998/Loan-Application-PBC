import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Transaction } from '../models/transaction.models';
import { User } from '../models/user.models';
import { throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class UserservicesService {

  constructor(private http: HttpClient) { }
  baseUrl: string = "http://localhost:8065/api";

  /*
  This service will take number type argument and then using HttpClient object ,
  it will use get request to retrieve number type observable object
  */
  showBalance(accNo: number) {
    return this.http.get<number>(this.baseUrl + "/get/" + accNo);
  }

  /*
This service will take two string type arguments and then using HttpClient object ,
it will use get request to retrieve boolean type observable object
If exception received from server then it will be caught and handled by the handleError method
*/
  validate(userName: string, password: string) {
    return this.http.get<boolean>(this.baseUrl + "/check/" + userName + "/" + password).pipe(catchError(this.handleError));
  }

  /*
This service will take one string type and one number type argument and then using HttpClient object ,
it will use get request to retrieve boolean type observable object
If exception received from server then it will be caught and handled by the handleError method
*/
  validateAccount(password: string, accNo: number) {
    return this.http.get<boolean>(this.baseUrl + "/checkacc/" + password + "/" + accNo).pipe(catchError(this.handleError));
  }

  /*
This service will take three number type arguments and then using HttpClient object ,
it will use get request to retrieve observable object
*/
  applyLoan(accNo: number, asset: number, loan: number) {
    return this.http.get(this.baseUrl + "/apply/" + accNo + "/" + asset + "/" + loan, { responseType: "text" });
  }
  /*
This service will take  one number type argument and then using HttpClient object ,
it will use get request to retrieve User type observable object
If exception received from server then it will be caught and handled by the handleError method
*/
  payEmi(accNo: number) {
    return this.http.get<User>(this.baseUrl + "/payEMI/" + accNo).pipe(catchError(this.handleError));
  }
  /*
This service will take two number type  argument and then using HttpClient object ,
it will use get request to retrieve User type observable object
If exception received from server then it will be caught and handled by the handleError method
*/
  calculateEmi(accNo: number, time: number) {
    return this.http.get<User>(this.baseUrl + "/calculate/" + accNo + "/" + time).pipe(catchError(this.handleError));
  }
  /*
This service will take  two number type argument and then using HttpClient object ,
it will use get request to retrieve text type observable object
*/
  deposit(accNo: number, amount: number) {
    return this.http.get(this.baseUrl + "/deposit/" + accNo + "/" + amount, { responseType: "text" })
  }
  /*
This service will take  one number type argument and then using HttpClient object ,
it will use get request to retrieve User type observable object
If exception received from server then it will be caught and handled by the handleError method
*/
  foreclose(accNo: number) {
    return this.http.get<User>(this.baseUrl + "/foreClose/" + accNo).pipe(catchError(this.handleError));
  }
  /*
This service will take  one number type argument and then using HttpClient object ,
it will use get request to retrieve list type observable object
*/
  transactions(accNo: number) {
    return this.http.get<Transaction[]>(this.baseUrl + "/printAll/" + accNo);
  }
  /*
This service will take  one User type argument and then using HttpClient object ,
it will use get request to post user object in the database
*/
  signup(user: User) {
    return this.http.post(this.baseUrl + "/add", user);
  }
  /*
This service will take  two string type arguments and then using HttpClient object ,
it will use get request to retrieve User type observable object
*/
  userdetails(username: String, password: String) {
    return this.http.get<User>(this.baseUrl + "/getdetails/" + username + "/" + password);
  }
  /*
This service will take  three string type arguments and then using HttpClient object ,
it will use get request to retrieve text type observable object
If exception received from server then it will be caught and handled by the handleError method
*/
  checkDatabase(e: String, ph: String, name: String) {
    return this.http.get(this.baseUrl + "/checkDb/" + e + "/" + ph + "/" + name, { responseType: "text" }).pipe(catchError(this.handleError));
  }
  /*
  This  method is used to handle the exceptions that might be received
  */
  private handleError(errorResponse: HttpErrorResponse) {
    return throwError(errorResponse);
  }

}
