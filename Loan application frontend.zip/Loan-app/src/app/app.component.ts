import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Loan-app';
  logout()
  {
    localStorage.removeItem("userName");
    localStorage.removeItem("password");
    localStorage.removeItem("name");
    localStorage.removeItem("emiAccount");
    if(localStorage.accountNum)
    {
      localStorage.removeItem("accountNum");
    }
  }
}
