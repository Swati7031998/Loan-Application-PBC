import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { AboutComponent } from './components/about/about.component';
import { ContactComponent } from './components/contact/contact.component';
import { ApplyLoanComponent } from './components/apply-loan/apply-loan.component';
import { CheckComponent } from './components/check/check.component';
import { PayEmiComponent } from './components/pay-emi/pay-emi.component';
import { ForecloseComponent } from './components/foreclose/foreclose.component';
import { CalculateEmiComponent } from './components/calculate-emi/calculate-emi.component';
import { PrintComponent } from './components/print/print.component';
import { TransactionsComponent } from './components/transactions/transactions.component';
import { DepositComponent } from './components/deposit/deposit.component';
import { ProfileComponent } from './components/profile/profile.component';
import { ListServicesComponent } from './components/list-services/list-services.component';
import { HttpClientModule} from '@angular/common/http';
import { ReactiveFormsModule,FormsModule } from '@angular/forms';
import { SignUpComponent } from './components/sign-up/sign-up.component';
import { PayEmi2Component } from './components/pay-emi2/pay-emi2.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AboutComponent,
    ContactComponent,
    ApplyLoanComponent,
    CheckComponent,
    PayEmiComponent,
    ForecloseComponent,
    CalculateEmiComponent,
    PrintComponent,
    TransactionsComponent,
    DepositComponent,
    ProfileComponent,
    ListServicesComponent,
    SignUpComponent,
    PayEmi2Component
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
