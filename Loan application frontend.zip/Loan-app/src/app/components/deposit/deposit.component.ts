import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserservicesService } from 'src/app/services/userservices.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {

  submitted: boolean = false;
  depositForm: FormGroup;
  msg1: boolean;
  message: String;
  errormsg: String;
  constructor(private formBuilder: FormBuilder, private router: Router, private userService: UserservicesService) { }

  ngOnInit() {
    if (!(localStorage.userName || localStorage.password)) {
      this.router.navigate(['']);
    }
    //This is to validate the group of form controls accNo,amount
    this.depositForm = this.formBuilder.group({
      accNo: ['', [Validators.required, Validators.pattern('.{5,}')]],
      amount: ['', [Validators.required, Validators.min(1)]]
    });
  }
  /*
  This method is used to deposit a certain balance in the account 
  In case of successful validations the message that amount is deposited is displayed in the alert box
  In case of any exception the corresponding error message is displayed in the alert box 
  */
  deposit() {
    this.submitted = true;
    if (this.depositForm.invalid) {
      return;
    }
    else {
      let accNo1 = this.depositForm.controls.accNo.value;
      let amount1 = this.depositForm.controls.amount.value;
      this.userService.validateAccount(localStorage.password, this.depositForm.controls.accNo.value).subscribe(data1 => {
        this.msg1 = data1;
        if (this.msg1 == true) {
          this.userService.deposit(accNo1, amount1).subscribe(data2 => {
            this.message = data2;
            alert(this.message);
            this.router.navigate(['list-services']);
          },
            err => {
              console.log(err.stack);
            });
        }
      },
        err => {
          this.errormsg = err.error;
          alert(this.errormsg);
        });
    }
  }

}
