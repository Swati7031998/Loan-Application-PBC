import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserservicesService } from 'src/app/services/userservices.service';

@Component({
  selector: 'app-apply-loan',
  templateUrl: './apply-loan.component.html',
  styleUrls: ['./apply-loan.component.css']
})
export class ApplyLoanComponent implements OnInit {
  submitted: boolean = false;
  applyForm: FormGroup;
  msg1: boolean;
  message: String;
  errormsg: String;
  errormsg1: String;
  constructor(private formBuilder: FormBuilder, private router: Router, private userService: UserservicesService) { }
  ngOnInit() {
    if (!(localStorage.userName || localStorage.password)) {
      this.router.navigate(['']);
    }
    //This is to validate the group of form controls accNo,asset,loanamt
    this.applyForm = this.formBuilder.group({
      accNo: ['', [Validators.required, Validators.pattern('.{5,}')]],
      asset: ['', [Validators.required, Validators.min(1)]],
      loanamt: ['', [Validators.required, Validators.min(1)]]
    });
  }
  /*
  This method is used to apply for loan if all the required validations are achieved
  In case of successful loan application the message thta loan is sanctioned is shown in alert box
  In case of any exception the corresponding error message is shown in alert box
  */
  apply() {
    this.submitted = true;
    if (this.applyForm.invalid) {
      return;
    }
    else {
      let accNo1 = this.applyForm.controls.accNo.value;
      let asset1 = this.applyForm.controls.asset.value;
      let loan = this.applyForm.controls.loanamt.value;
      this.userService.validateAccount(localStorage.password, this.applyForm.controls.accNo.value).subscribe(data1 => {
        this.msg1 = data1;
        if (this.msg1 == true) {
          this.userService.applyLoan(accNo1, asset1, loan).subscribe(data2 => {
            this.message = data2;
            if (this.message == "OK") {
              alert("Loan of Rs. " + loan + " has been sanctioned!!");
              this.router.navigate(['list-services']);
            }
            else {
              alert(this.message);
            }
          },
            err => {
              this.errormsg1 = err.error;
              alert(this.errormsg1);
            });
        }
      },
        err => {
          this.errormsg = err.error;
          alert(this.errormsg);
        });

    }
  }

}
