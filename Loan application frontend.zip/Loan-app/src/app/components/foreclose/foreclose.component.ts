import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserservicesService } from 'src/app/services/userservices.service';
import { User } from 'src/app/models/user.models';

@Component({
  selector: 'app-foreclose',
  templateUrl: './foreclose.component.html',
  styleUrls: ['./foreclose.component.css']
})
export class ForecloseComponent implements OnInit {


  submitted: boolean = false;
  forecloseForm: FormGroup;
  msg1: boolean;
  message: String;
  user: User;
  errormsg:String;
  constructor(private formBuilder: FormBuilder, private router: Router, private userService: UserservicesService) { }

  ngOnInit() {
    if (!(localStorage.userName || localStorage.password)) {
      this.router.navigate(['']);
    }
    //This is to validate the group of form controls accNo
    this.forecloseForm = this.formBuilder.group({
      accNo: ['', [Validators.required,Validators.pattern('.{5,}')]]
        });
    this.details();
  }
  /*
  This method is used to foreclose the loan amount against a particular account number
  In case of successful validation the message that foreclose successful or Self foreclose denied is shown in the alert box
  In cse of an Excepton the corresponding error message is displayed in the alert box
  */
  foreclose() {
    this.submitted = true;
    if (this.forecloseForm.invalid) {
      return;
    }
    else {
      let accNo1 = this.forecloseForm.controls.accNo.value;
      this.userService.validateAccount(localStorage.password, this.forecloseForm.controls.accNo.value).subscribe(data1 => {
        this.msg1 = data1;
        if (this.msg1 == true) {
          this.userService.foreclose(accNo1).subscribe(data2 => {
            this.user = data2;
             if (localStorage.loan > 0 && this.user.loan_amount == 0.0 && this.user.balance>=localStorage.loan) {
              this.message = "Foreclose successful";
              localStorage.removeItem("loan");
            }
            else {
              this.message = "Self foreclose denied.We have to sell your assets to clear the loan amount";
              localStorage.removeItem("loan");
            }
            alert(this.message);
            this.router.navigate(['list-services']);
          },
            err => {
             this.errormsg=err.error;
             alert(this.errormsg);
            });
        }
      },
        err => {
          this.errormsg=err.error;
        alert(this.errormsg);
        });
    }
  }
  /*
  This method is used to fetch the user details againt corresponding username and password
  In this case it is used to fetch the loan amount before foreclose
  */
  details(){
    this.userService.userdetails(localStorage.userName,localStorage.password).subscribe(data=>{
      this.user=data;
      localStorage.loan=this.user.loan_amount;
    },
    err=>{
      console.log(err.stack);
    })
  }


}
