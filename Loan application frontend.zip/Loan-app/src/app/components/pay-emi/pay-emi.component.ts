import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { UserservicesService } from 'src/app/services/userservices.service';
import { User } from 'src/app/models/user.models';

@Component({
  selector: 'app-pay-emi',
  templateUrl: './pay-emi.component.html',
  styleUrls: ['./pay-emi.component.css']
})
export class PayEmiComponent implements OnInit {

  payForm: FormGroup;
  submitted: boolean = false;
  msg1: boolean;
  message: String;
  user: User;
  errormsg:String;
  constructor(private formBuilder: FormBuilder, private router: Router, private userService: UserservicesService) { }

  ngOnInit() {
    if (!(localStorage.userName || localStorage.password)) {
      this.router.navigate(['']);
    }
    if (!localStorage.emi) {
      this.router.navigate(['calculate-emi']);
    }
    //This is to validate the group of form controls accNo
    this.payForm = this.formBuilder.group({
      accNo: ['', [Validators.required,Validators.pattern('.{5,}')]]
        });
    this.details();
  }
  /*
  This method is used for account validation
  In case of successful validation the next page displaying the EMI appears
  In case of Exception the coreesponding error message is shown in an alert box
  */
  pay() {
    this.submitted = true;
    if (this.payForm.invalid) {
      return;
    }
    else {
      let accNo1 = this.payForm.controls.accNo.value;
      this.userService.validateAccount(localStorage.password, this.payForm.controls.accNo.value).subscribe(data1 => {
        this.msg1 = data1;
        if (this.msg1 == true) {
          localStorage.emiAccount = this.payForm.controls.accNo.value;
          if (localStorage.loan == 0.0 && this.user.loan_amount == 0.0) {
            this.message = "No pending loans on this account";
            alert(this.message);
            localStorage.removeItem("loan");
            this.router.navigate(['list-services']);
          }
          else {
            this.router.navigate(['pay-emi2']);
          }
        }
      },
        err => {
          this.errormsg=err.error;
        alert(this.errormsg);
        });
    }
  }

  /*
  This method is used to fetch the user details against a particular username and password
  In this case it is used to check the loan amount beforehand
  In case the loan amount is 0 the message that there are no loans against this account number is shown by the pay method above
  */
  details() {
    this.userService.userdetails(localStorage.userName, localStorage.password).subscribe(data => {
      this.user = data;
      localStorage.loan = this.user.loan_amount;
    },
      err => {
        console.log(err.stack);
      })
  }
}
