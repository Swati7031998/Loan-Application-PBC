import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PayEmi2Component } from './pay-emi2.component';

describe('PayEmi2Component', () => {
  let component: PayEmi2Component;
  let fixture: ComponentFixture<PayEmi2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PayEmi2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PayEmi2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
