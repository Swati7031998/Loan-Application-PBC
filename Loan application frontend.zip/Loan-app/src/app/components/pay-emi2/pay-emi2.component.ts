import { Component, OnInit } from '@angular/core';
import { UserservicesService } from 'src/app/services/userservices.service';
import { Router } from '@angular/router';
import { User } from 'src/app/models/user.models';

@Component({
  selector: 'app-pay-emi2',
  templateUrl: './pay-emi2.component.html',
  styleUrls: ['./pay-emi2.component.css']
})
export class PayEmi2Component implements OnInit {
  emi: number;
  message: String;
  user: User;
  errormsg: String;
  constructor(private userService: UserservicesService, private router: Router) { }

  ngOnInit() {
    this.emi = localStorage.emi;
  }
  /*
  This method is used for payment of EMI
  In case of successful validation the EMI payment is successful is shown in the alert box
  In case of any Exception the coreesponding error message is shown in the alert box
  */
  continue() {
    this.userService.payEmi(localStorage.emiAccount).subscribe(data2 => {
      this.user = data2;
      this.message = "An amount of Rs. " + localStorage.emi + " has been deducted from your account. Remaining balance is " + this.user.balance;

      alert(this.message);
      localStorage.removeItem('emi');
      this.router.navigate(['list-services']);
    },
      err => {
        this.errormsg = err.error;
        alert(this.errormsg);
      });
  }

  // This method is used to cancel the process of EMI payment and redirect to the list-services page

  cancel() {
    localStorage.removeItem("emi");
    this.router.navigate(['list-services']);
  }

}
