import { Component, OnInit } from '@angular/core';
import { Transaction } from 'src/app/models/transaction.models';
import { UserservicesService } from 'src/app/services/userservices.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-transactions',
  templateUrl: './transactions.component.html',
  styleUrls: ['./transactions.component.css']
})
export class TransactionsComponent implements OnInit {
  results: Transaction[];
  constructor(private userService: UserservicesService, private router: Router) { }

  ngOnInit() {
    if (!(localStorage.userName || localStorage.password)) {
      this.router.navigate(['']);
    }
    if ((localStorage.userName && localStorage.password) && !(localStorage.accountNum)) {
      this.router.navigate(['list-services']);
    }
    this.transaction1();
  }
  /*
  This method is used to fetch the Transaction list from the database aginst a particular account number
  The list is then displayed in table format
  */
  transaction1() {
    this.userService.transactions(localStorage.accountNum).subscribe(data => {
      this.results = data;
    },
      err => {
        console.log(err.stack);
      })
  }
  // This method is used to redirect to list-services page when Back button is clicked
  do() {
    localStorage.removeItem("accountNum");
    this.router.navigate(['list-services']);
  }



}
