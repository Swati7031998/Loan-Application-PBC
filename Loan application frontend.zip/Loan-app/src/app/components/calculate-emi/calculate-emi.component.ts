import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserservicesService } from 'src/app/services/userservices.service';
import { User } from 'src/app/models/user.models';

@Component({
  selector: 'app-calculate-emi',
  templateUrl: './calculate-emi.component.html',
  styleUrls: ['./calculate-emi.component.css']
})
export class CalculateEmiComponent implements OnInit {

  submitted: boolean = false;
  calculatForm: FormGroup;
  ms1: boolean;
  message: number;
  user: User;
  errormsg: String;
  constructor(private formBuilder: FormBuilder, private router: Router, private userService: UserservicesService) { }

  ngOnInit() {
    if (!(localStorage.userName || localStorage.password)) {
      this.router.navigate(['']);
    }
    //This is to validate the group of form controls accNo,time 
    this.calculatForm = this.formBuilder.group({
      accNo: ['', [Validators.required,Validators.pattern('.{5,}')]],
      time: ['', [Validators.required,Validators.min(1),Validators.max(10)]]
    });
  }
  /*
  This method is used to calculate the EMI upon successful validations 
  In case of successful validations the calculated EMI will bedisplayed in the alert box
  In case of an exception the corresponding error message is shown in the alert box
  */ 
  calculate() {
    this.submitted = true;
    if (this.calculatForm.invalid) {
      return;
    }
    else {
      let accNo1 = this.calculatForm.controls.accNo.value;
      let time1 = this.calculatForm.controls.time.value;
      this.userService.validateAccount(localStorage.password, this.calculatForm.controls.accNo.value).subscribe(data1 => {
        this.ms1 = data1;
        if (this.ms1 == true) {
          this.userService.calculateEmi(accNo1, time1).subscribe(data2 => {
            this.user = data2;
            this.message = this.user.emi;
            localStorage.emi = this.message;
            alert("Your monthly emi will be " + this.message);
            this.router.navigate(['list-services']);
          },
            err => {
              this.errormsg = err.error;
              alert(this.errormsg);
            });
        }
      },
        err => {
          this.errormsg = err.error;
          alert(this.errormsg);
        });
    }
  }

}
