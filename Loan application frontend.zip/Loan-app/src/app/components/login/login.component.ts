import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserservicesService } from 'src/app/services/userservices.service';
import { User } from 'src/app/models/user.models';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  submitted: boolean= false;
  invalidLogin:boolean = false;
  msg:boolean;
  errormsg:String;
  
  constructor(private formBuilder:FormBuilder,private router:Router,private userService:UserservicesService) { }

  ngOnInit() {
    //If the local storage has some value during login then it is cleared 
    if(localStorage.userName || localStorage.password ||localStorage.loan|| localStorage.accountNum||localStorage.emi||localStorage.name ||localStorage.emiAccount){
      localStorage.removeItem("userName");
      localStorage.removeItem("password");
      localStorage.removeItem("accountNum");
      localStorage.removeItem("emiAccount");
      localStorage.removeItem("name");
      localStorage.removeItem("emi");
      localStorage.removeItem("loan");
    }
    //This is to validate the group of form controls username,password
    this.loginForm = this.formBuilder.group({
      username:['',Validators.required],
      password: ['', Validators.required]
    });
    
  }
  /*
  This method is used to verify the username and password with the username -password pairs in the database
  If the username and password are verified the list-services page is displayed to the user
  In case of any exception the corresponding error message is displayed in the alert box
  */
  verifyLogin(){
    this.submitted = true;
    if(this.loginForm.invalid){
      return;
    }
    let username = this.loginForm.controls.username.value;
    let password = this.loginForm.controls.password.value;
   localStorage.userName=username;
   localStorage.password=password;
    this.userService.validate(username,password).subscribe(data => {
      this.msg= data;
      if(this.msg==true)
    {
      this.router.navigate(['list-services']);
    }
    
      
    },
      err => {
        this.errormsg=err.error;
        this.invalidLogin = true;
        alert(this.errormsg);
      });
    
  } 
}
