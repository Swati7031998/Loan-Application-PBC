import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { UserservicesService } from 'src/app/services/userservices.service';

@Component({
  selector: 'app-print',
  templateUrl: './print.component.html',
  styleUrls: ['./print.component.css']
})
export class PrintComponent implements OnInit {

  submitted: boolean = false;
  printForm: FormGroup;
  msg: boolean;
  errormsg: String;
  constructor(private formBuilder: FormBuilder, private router: Router, private userService: UserservicesService) { }

  ngOnInit() {
    if (!(localStorage.userName || localStorage.password)) {
      this.router.navigate(['']);
    }
    //This is to validate the group of form controls accNo
    this.printForm = this.formBuilder.group({
      accNo: ['', [Validators.required, Validators.pattern('.{5,}')]]

    });
  }
  /*
  This method is used to validate Account Number
  In case ofsuccessful validation the next page with Transaction Table appears
  In case of Exception the corresponding error message is shown in the alert box
  */
  print() {
    this.submitted = true;
    if (this.printForm.invalid) {
      return;
    }
    else {
      this.userService.validateAccount(localStorage.password, this.printForm.controls.accNo.value).subscribe(data1 => {
        this.msg = data1;
        if (this.msg == true) {
          localStorage.accountNum = this.printForm.controls.accNo.value;
          this.router.navigate(['transactions']);
        }

      },
        err => {
          this.errormsg = err.error;
          alert(this.errormsg);
        });

    }
  }
}
