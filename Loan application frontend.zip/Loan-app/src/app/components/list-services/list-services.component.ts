import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserservicesService } from 'src/app/services/userservices.service';
import { User } from 'src/app/models/user.models';

@Component({
  selector: 'app-list-services',
  templateUrl: './list-services.component.html',
  styleUrls: ['./list-services.component.css']
})
export class ListServicesComponent implements OnInit {
user:User;
name:String;
  constructor(private router:Router,private userService:UserservicesService) { }

  ngOnInit() {
    if(!(localStorage.userName || localStorage.password))
      this.router.navigate(['']);
      this.details();
  }
  /*
  This method is called when the logout button is clicked
  It will clear the local Storage to forget the details used during the session
  */
  forget()
  {
    localStorage.removeItem("userName");
    localStorage.removeItem("password");
    localStorage.removeItem("name");
    localStorage.removeItem("emiAccount");
    if(localStorage.accountNum){
      localStorage.removeItem("accountNum");
    }
    this.router.navigate(['']);
  }
  /*
  This method is used to fetch the details of a user againt entered username and password
  In this case this method is needed to store the name of the user to show it on the welcome page via interpolation
  */
  details(){
    this.userService.userdetails(localStorage.userName,localStorage.password).subscribe(data=>{
      this.user=data;
      localStorage.name=this.user.name;
      this.name=localStorage.name;
    },
    err=>{
      console.log(err.stack);
    })
  }

}
