import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/models/user.models';
import { UserservicesService } from 'src/app/services/userservices.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  user: User;
  constructor(private userService: UserservicesService, private router: Router) { }

  ngOnInit() {
    if (!(localStorage.userName || localStorage.password)) {
      this.router.navigate(['']);
    }
    this.details();
  }
  //This method is used to go back to the list-services page when the back button is clicked
  do() {
    this.router.navigate(['list-services']);
  }
  /*
  This method is used to fetch the user details from the databse against a particular username and password
  In this case it is used to display the details on the page
  */
  details() {
    this.userService.userdetails(localStorage.userName, localStorage.password).subscribe(data => {
      this.user = data;
    },
      err => {
        console.log(err.stack);
      })
  }
}
