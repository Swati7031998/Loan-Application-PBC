import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { User } from 'src/app/models/user.models';
import { Router } from '@angular/router';
import { UserservicesService } from 'src/app/services/userservices.service';
import { CustomValidator } from 'src/app/custom-validator';
import { CustomValidator2 } from 'src/app/custom-validator2';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
  addForm: FormGroup;
  submitted: boolean = false;
  user: User;
  msg: String;
  errormsg: String;
  constructor(private formBuilder: FormBuilder, private router: Router, private userService: UserservicesService) { }
  ngOnInit() {
    //This is to validate the group of form controls username,password,phoneNumber,balance,emailid,name
    this.addForm = this.formBuilder.group({
      username: ['', [Validators.required, Validators.minLength(7)]],
      password: ['', Validators.compose([
        Validators.required,
        Validators.minLength(8),
        CustomValidator.patternValidator(/\d/, { hasNumber: true }),
        CustomValidator.patternValidator(/[A-Z]/, { hasCapitalCase: true }),
        CustomValidator.patternValidator(/[a-z]/, { hasSmallCase: true }),
        CustomValidator.patternValidator(/[?=.*/'":;<>~|[\]{}\\!@#$%^&()]/, { hasSpecialCharacters: true })
      ])],
      phonenumber: ['', Validators.compose([
        Validators.required,
        Validators.pattern("[6-9][0-9]{9}"),
        CustomValidator2.patternValidator(/[?=.*/'":;<>~|[\]{}\\!@#$%^&()]/, { hasSpecialCharacters: true }),
        CustomValidator2.patternValidator(/[A-Za-z]/, { hasLetters: true })
      ])],

      balance: ['', [Validators.required, Validators.min(100000)]],
      emailid: ['', [Validators.required, Validators.email]],
      name: ['', Validators.compose([
        Validators.required,
        CustomValidator.patternValidator(/^([A-Z][a-z]((\s[A-Za-z])?[a-z])*)$/, { hasCapitalCase: true }),
        CustomValidator2.patternValidator(/\d/, { hasNumber: true }),
        CustomValidator2.patternValidator(/[?=.*/'":;<>~|[\]{}\\!@#$%^&()]/, { hasSpecialCharacters: true })
      ])]
    });
  }

  /*
  This method is used to verify whether the entered data already exists in the database or not
  If the data does not exist in the database then the signup service creates a new account and the messge with account number is shown in the alert box
  In case of any Exception the corresponding error message is displayed in the alert box
  */
  verify() {
    this.submitted = true;
    if (this.addForm.invalid)
      return;
    else {
      this.userService.checkDatabase(this.addForm.controls.emailid.value, this.addForm.controls.phonenumber.value, this.addForm.controls.username.value).subscribe(data1 => {
        this.msg = data1;
        if (this.msg) {
          this.userService.signup(this.addForm.value).subscribe(data => {
            alert("Account successfully created!!Your account number is  " + data);
            alert("Check your acount and other details in the services page after logging in to your account");
            this.router.navigate(['']);
          },
            err => {
              console.log(err.stack);
            });
        }
      },
        err => {
          this.errormsg = err.error;
          alert(this.errormsg);

        });

    }
  }

}
