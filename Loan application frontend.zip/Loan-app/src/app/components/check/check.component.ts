import { Component, OnInit } from '@angular/core';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { UserservicesService } from 'src/app/services/userservices.service';

@Component({
  selector: 'app-check',
  templateUrl: './check.component.html',
  styleUrls: ['./check.component.css']
})
export class CheckComponent implements OnInit {

  submitted: boolean = false;
  checkForm: FormGroup;
  message: number;
  msg: boolean;
  errormsg=String;
  constructor(private formBuilder: FormBuilder, private router: Router, private userService: UserservicesService) { }

  ngOnInit() {
    if(!(localStorage.userName || localStorage.password))
    {
      this.router.navigate(['']);
    }
   // This is to validate the group of form controls accNo//
    this.checkForm = this.formBuilder.group({
      accNo: ['', [Validators.required,Validators.pattern('.{5,}')]]
        });
  }
  /*
  This method is used to check the account balance against a particular account number
  In case of sucessful validations the account balance is diaplayed in the alert box
  In case of an exception the corresponding error message is displayed in the alert box
  */
  check() {
    this.submitted = true;
    if (this.checkForm.invalid) {
      return;
    }
    else {
      this.userService.validateAccount(localStorage.password, this.checkForm.controls.accNo.value).subscribe(data1 => {
        this.msg = data1;
        if (this.msg == true) {
          this.userService.showBalance(this.checkForm.controls.accNo.value).subscribe(data => {
            this.message = data;
            alert("Your account balance is " + this.message);
            this.router.navigate(['list-services']);
          },
            err => {
              console.log(err.stack);
            });
        }
        // else {
        //   alert('Sorry!Account does nor exist');
        // }
      },
        err => {
          this.errormsg=err.error;
        alert(this.errormsg);
        });
      
    }
  }

}
