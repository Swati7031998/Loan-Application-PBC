package com.cg.LoanPhase3Implementation.entities;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Passbook")
public class Transactions implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name="Transaction_ID")
	private int id;
	@Column(name="Account_Number")
	private int account_number;
	@Column(name="Transaction")
	private String transaction;

	public Transactions(int id, int account_number, String transaction) {
		super();
		this.id = id;
		this.account_number = account_number;
		this.transaction = transaction;
	}
	public Transactions() {
		super();
	}   
	public int getId() {
		return this.id;
	}

	public void setId(int id) {
		this.id = id;
	}   
	public int getAccount_number() {
		return this.account_number;
	}

	public void setAccount_number(int account_number) {
		this.account_number = account_number;
	}   
	public String getTransaction() {
		return this.transaction;
	}

	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}

}
