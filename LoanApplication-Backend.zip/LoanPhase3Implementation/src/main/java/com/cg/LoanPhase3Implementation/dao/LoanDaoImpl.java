package com.cg.LoanPhase3Implementation.dao;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.cg.LoanPhase3Implementation.entities.Bankloan;
import com.cg.LoanPhase3Implementation.entities.Transactions;
import com.cg.LoanPhase3Implementation.exceptions.InvalidAccountException;
import com.cg.LoanPhase3Implementation.exceptions.InvalidLoginException;
import com.cg.LoanPhase3Implementation.exceptions.UserAlreadyExistsException;
@Repository
public class LoanDaoImpl implements LoanDao {
	static int accNum=10030;
	static int id=2121;
	@Autowired
	EntityManager entity_manager;
	Logger logger=LoggerFactory.getLogger(LoanDaoImpl.class);
	
	/**
	 * This method is used for validation of username and password
	 * @param username This is the first parameter to validate method 
	 * @param password This is the second parameter to validate method
	 * @return boolean This returns true if the username and password are valid and exist in the database
	 * @throws InvalidLoginException This exception is thrown if the username or password is/are invalid
	 */
	@Override
	public boolean validate(String username, String password)throws InvalidLoginException {
		logger.trace("Validate is accessed at dao layer");
		String query="select b from Bankloan b where b.password=:puser and b.username=:uname";
		TypedQuery<Bankloan> query1=entity_manager.createQuery(query,Bankloan.class);
		query1.setParameter("puser",password);
		query1.setParameter("uname",username);
		try {
			Bankloan bank=query1.getSingleResult();
			if(bank!=null)
			{
				logger.info("User login successful");
				return true;
			}
			else {
				logger.error("InvalidLoginException thrown by validate method");
				throw new InvalidLoginException("Account does not exist");
			}
		}
		catch(NoResultException ex) {
			logger.error("InvalidLoginException thrown by validate method");
			throw new InvalidLoginException("Account does not exist");
		}

	}
	/**
	 * This method is used for validation of account number
	 * @param password This is the first parameter to validateAccount method
	 * @param account_number This is the second parameter to validateAccount method
	 * @return boolean This returns true if the account number entered by the user matches the account number existing in the database for that password
	 * @throws InvalidAccountException This exception is thrown when the account_number entered is not valid for the given password or does not exist in the database
	 */
	@Override
	public boolean validateAccount(String password, int account_number)throws InvalidAccountException {
		logger.trace("Validate Account is accessed at dao layer");
		String query="select b from Bankloan b where b.password=:pass";
		TypedQuery<Bankloan> query1=entity_manager.createQuery(query,Bankloan.class);
		query1.setParameter("pass",password);
		Bankloan bank=query1.getSingleResult();
		try {
			if(bank.getAccount_number()==account_number && bank!=null)
			{
				logger.info("User account validated");
				return true;
			}
			else {
				logger.error("InvalidAccountException thrown by validateAccount method");
				throw new InvalidAccountException("Sorry!Account does not exist!!");
			}
		}
		catch(Exception ex) {
			logger.error("InvalidAccountException thrown by validateAccount method");
			throw new InvalidAccountException("Sorry!Account does not exist!!");

		}
	}
	/**
	 * This method is used to apply for loan
	 * @param account_number This is the first parameter to applyLoan method
	 * @param asset This is the second paramter to applyLoan method
	 * @param loan This is the third paramter to applyLoan method
	 * @return String This returns string value "OK" if the user is qualified to apply for loan or the other message to be displayed
	 */
	@Override
	public String applyLoan(Integer account_number,double asset,double loan){
		logger.trace("Apply Loan is accessed at dao layer");
		Bankloan bank=entity_manager.find(Bankloan.class,account_number);
		double amount1=bank.getLoan_amount();
		String command="select count(p.id) from Transactions p";
		TypedQuery<Long> query=entity_manager.createQuery(command,Long.class);
		long count=query.getSingleResult();
		if( asset > loan && bank.getBalance()>=100000 && (loan>=30000 && loan <=3000000))
		{
			logger.info("Loan application successful");
			bank.setLoan_amount(loan+amount1);
			entity_manager.merge(bank);
			if(count>0) {
				command="select max(p.id) from Transactions p";
				TypedQuery<Integer> q3=entity_manager.createQuery(command,Integer.class);
				id=q3.getSingleResult();
				id+=1;
			}
			Transactions transaction=new Transactions(id,bank.getAccount_number(),"Loan of amount: "+loan+" taken");
			entity_manager.persist(transaction);
			return "OK";
		}
		else if(asset<loan) {
			logger.error("Asset value must be greater than loan amount");
			return "Your asset value must be greater than loan amount";
		}
		else if(bank.getBalance()<100000) {
			logger.error("Account balance must be greater than 1 lakh to apply for loan");
			return "Your account balance must be greater than 1 lakh to apply for loan";
		}
		else {
			logger.error("Loan amount should be between 30000 and 3000000");
			return "Your loan amount should be between 30000 and 3000000";
		}

	}

	/**
	 * This method is used to pay Equated Monthly Installments(EMI)
	 * @param bank This is the only parameter to payEmi method
	 * @return Bankloan This is returned after the changes made to the Bankloan object after EMI payment is saved to the database
	 */
	@Override
	public Bankloan payEmi(Bankloan bank){
		logger.trace("Pay EMI is accessed at dao layer");
		Bankloan bank_account=entity_manager.find(Bankloan.class,bank.getAccount_number());
		String command="select count(p.id) from Transactions p";
		TypedQuery<Long> query=entity_manager.createQuery(command,Long.class);
		long count=query.getSingleResult();
		if(bank_account.getEmi()<=bank_account.getLoan_amount() && bank_account.getEmi()<=bank_account.getBalance())

		{
			logger.info("EMI payment successful");
			if(count>0) {
				command="select max(p.id) from Transactions p";
				TypedQuery<Integer> q3=entity_manager.createQuery(command,Integer.class);
				id=q3.getSingleResult();
				id++;
			}
			Transactions t=new Transactions(id,bank_account.getAccount_number(),"EMI of Rs. "+bank_account.getEmi()+" paid");
			entity_manager.persist(t);
			bank_account.setEmi(0.0);
			return entity_manager.merge(bank_account);
		}
		else {
			logger.error("EMI paymemt unsuccessful");
			return entity_manager.merge(bank_account);

		}
	}


	/**
	 * This method is used to deposit balance into the given account number
	 * @param account_number This is the first paramter to deposit method
	 * @param deposit_amount This is the second paramter to deposit method
	 * @return String This returns custom String message after successful deposit
	 */
	@Override
	public String deposit(Integer account_number,double deposit_amount) {
		logger.trace("Deposit is accessed at dao layer");
		Bankloan bank=entity_manager.find(Bankloan.class,account_number);
		double balance=bank.getBalance();
		bank.setBalance(balance+deposit_amount);
		entity_manager.merge(bank);
		String command="select count(p.id) from Transactions p";
		TypedQuery<Long> q1=entity_manager.createQuery(command,Long.class);
		long count=q1.getSingleResult();
		if(count>0) {
			command="select max(p.id) from Transactions p";
			TypedQuery<Integer> q3=entity_manager.createQuery(command,Integer.class);
			id=q3.getSingleResult();
			id++;
		}
		Transactions transaction=new Transactions(id,bank.getAccount_number(),"Amount of Rs. "+deposit_amount+" deposited");
		entity_manager.persist(transaction);
		return "The amount "+deposit_amount+" is successfully added to your acount!!";
	}

	/**
	 * This method is used for foreclose
	 * @param bank This is the only parameter to foreClose method
	 * @return Bankloan This is returned after the changes made to the Bankloan object after foreclose is saved to the database
	 */
	@Override
	public Bankloan foreClose(Bankloan bank){
		logger.trace("Foreclose is accessed at dao layer");
		Bankloan bank_account=entity_manager.find(Bankloan.class,bank.getAccount_number());
		String command="select count(p.id) from Transactions p";
		TypedQuery<Long> q1=entity_manager.createQuery(command,Long.class);
		long count=q1.getSingleResult();
		if(bank_account.getBalance()>=bank_account.getLoan_amount())
		{
			
			if(count>0) {
				command="select max(p.id) from Transactions p";
				TypedQuery<Integer> q3=entity_manager.createQuery(command,Integer.class);
				id=q3.getSingleResult();
				id++;
			}
			Transactions transaction=new Transactions(id,bank_account.getAccount_number(),"Amount of Rs. "+bank_account.getLoan_amount()+" deducted against foreclose");
			entity_manager.persist(transaction);
			bank_account.setLoan_amount(0.0);
			return entity_manager.merge(bank_account);
		}
		else
		{
			return entity_manager.merge(bank_account);
		}
	}

	/**This method is used to calculate the Equated Monthly Installments(EMI)
	 * @param bank This is the only parameter to calcEmi method
	 * @return Bankloan This is returned after the changes made to the Bankloan object after EMI calculation is saved to the database
	 */
	@Override
	public Bankloan calcEmi(Bankloan bank){
		logger.trace("Calculate EMI is accessed at dao layer");
		Bankloan bank_account=entity_manager.find(Bankloan.class,bank.getAccount_number());
		return entity_manager.merge(bank_account);
	}

	/**
	 * This method is used for creating a new loan account
	 * @param account This is the only parameter to createAccount method
	 * @return int This returns the account number generated after the user successfully creates a new loan account
	 */
	@Override
	public int createAccount(Bankloan account) {
		logger.trace("Create Account is accessed at dao layer");
		String query1="select count(bk.account_number) from Bankloan bk";
		TypedQuery<Long> q1=entity_manager.createQuery(query1,Long.class);
		long result=q1.getSingleResult();
		int count=(int)result;
		if(count>0) {
			String query="select max(bk.account_number) from Bankloan bk";
			TypedQuery<Integer> q=entity_manager.createQuery(query,Integer.class);
			int max_account_number=q.getSingleResult();
			account.setAccount_number(max_account_number+1);
		}
		else
			account.setAccount_number(accNum);
		account.setLoan_amount(0.0);
		entity_manager.persist(account);
		return account.getAccount_number();


	}
	/**
	 * This method is used to show the existing account balance
	 * @param accNo This is the only paramter to showBalance method
	 * @return double This returns the existing account balance
	 */
	@Override
	public double showBalance(Integer accNo) {
		logger.trace("Show Balance is accessed at dao layer");
		Bankloan bank = entity_manager.find(Bankloan.class,accNo);
		return bank.getBalance();

	}


	/**
	 * This method is used to get the Customer details for the corresponding username and password
	 * @param username This is the first parameter to getCust method
	 * @param password This is the second parameter to getCust method
	 * @return Bankloan This returns the object matching the given username and password
	 */
	@Override
	public Bankloan getCust(String username, String password) {
		logger.trace("Get Customer Details is accessed at dao layer");
		String query="select b from Bankloan b where b.username=:user and b.password=:pass";
		TypedQuery<Bankloan> q=entity_manager.createQuery(query,Bankloan.class);
		q.setParameter("user", username);
		q.setParameter("pass", password);
		Bankloan bank_account=q.getSingleResult();
		return bank_account;

	}

	/**
	 * This method is used to get the transactions against a given account number
	 * @param accNo This is the only paramter to printTransaction method
	 * @return List<Transactions> This returns the list of transaction aginst a given account number
	 */
	@Override
	public List<Transactions> printTransaction(Integer accNo) {
		logger.trace("Print Transaction is accessed at dao layer");
		List<Transactions> transaction_list=new ArrayList<>();
		String query="select t from Transactions t where t.account_number=:accNo";
		TypedQuery<Transactions> q=entity_manager.createQuery(query,Transactions.class);
		q.setParameter("accNo",accNo);
		transaction_list=q.getResultList();
		Collections.sort(transaction_list,compareById);
		return transaction_list;
	}
	/**
	 * This method is used to check whether the details entered by the user during sign up already exist
	 * @param email_id This is the first parameter to checkDb method
	 * @param phone_number This is the second parameter to checkDb method
	 * @param username This is the third parameter to checkDb method
	 * @return String This returns a String value "OK" if the record does not exist in the database already
	 * @throws UserAlreadyExistsException This exception is thrown if the username,email address or password entered already exist in the database
	 */
	@Override
	public String checkDb(String email_id,String phone_number,String username)throws UserAlreadyExistsException {
		logger.trace("Check Database is accessed at dao layer");
		List<String> emails=new ArrayList<>();
		List<String> names=new ArrayList<>();
		List<String> phone_numbers=new ArrayList<>();
		String str="SELECT b.emailid from Bankloan b";
		TypedQuery<String> query=entity_manager.createQuery(str,String.class);
		emails=query.getResultList();
		String str2="SELECT b.username from Bankloan b";
		TypedQuery<String> query2=entity_manager.createQuery(str2,String.class);
		names=query2.getResultList();
		String str1="SELECT b.phonenumber from Bankloan b";
		TypedQuery<String> query1=entity_manager.createQuery(str1,String.class);
		phone_numbers=query1.getResultList();
		if(phone_numbers.contains(phone_number)||emails.contains(email_id)) {
			logger.error("USerAlreadyExistsException thrown by checkDb method");
			throw new UserAlreadyExistsException( "You already have an account!Please kindly login!!");
		}
		else if(names.contains(username)) {
			logger.error("USerAlreadyExistsException thrown by checkDb method");
			throw new UserAlreadyExistsException( "User name exists");
		}
		else {
			logger.info("account can be created");
			return "OK";
		}
	}

	/**
	 * This method is used to get the Customer details by account number
	 * @param account_number This is the only parameter to getCustbyaccount method
	 * @return Bankloan This returns the Bankloan object with the details of the user with a given account number
	 */
	public Bankloan getCustbyaccount(Integer account_number) {
		return entity_manager.find(Bankloan.class,account_number);
	}

	//Comparator used to sort the transaction list
	Comparator<Transactions> compareById=new Comparator<Transactions>() {
		public int compare(Transactions o1,Transactions o2) {
			return (o1.getId()>o2.getId())?1:0;
		}
	};
}
