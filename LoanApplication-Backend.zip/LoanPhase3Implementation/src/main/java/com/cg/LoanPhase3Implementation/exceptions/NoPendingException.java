package com.cg.LoanPhase3Implementation.exceptions;

public class NoPendingException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	public NoPendingException(String message) {
		super(message);
	}

}
