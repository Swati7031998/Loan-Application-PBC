package com.cg.LoanPhase3Implementation;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cg.LoanPhase3Implementation.entities.Bankloan;
import com.cg.LoanPhase3Implementation.entities.Transactions;
import com.cg.LoanPhase3Implementation.service.LoanServiceImpl;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins="http://localhost:4200")
public class LoanController {
	@Autowired
	LoanServiceImpl loanService;
	Logger logger=LoggerFactory.getLogger(LoanController.class);
	/* 
	 * When /add is mapped with client request createAccount method is called at service layer
	 * In case of any exception the Controller shall take care of it using ExceptionHandlerControllerAdvice
	 */
	@PostMapping("/add")
	public int createAccount(@RequestBody Bankloan account)
	{
		logger.trace("Create Account method is accessed");
		return loanService.createAccount(account);
	}

	/* 
	 * When /getdetails/{username}/{password} is mapped with client request getCust method is called at service layer
	 * In case of any exception the Controller shall take care of it using ExceptionHandlerControllerAdvice
	 */

	@GetMapping("/getdetails/{username}/{password}")
	public Bankloan getCust(@PathVariable String username,@PathVariable String password) {
		logger.trace("Get Customer Details is accessed");
		return loanService.getCust(username, password);
	}

	/* 
	 * When /apply/{accNo}/{asset}/{loan} is mapped with client request applyLoan method is called at service layer
	 * In case of any exception the Controller shall take care of it using ExceptionHandlerControllerAdvice
	 */
	@GetMapping("/apply/{accNo}/{asset}/{loan}")
	public String applyLoan(@PathVariable Integer accNo,@PathVariable double asset,@PathVariable double loan)
	{
		logger.trace("Apply Loan is accessed");
		return loanService.applyLoan(accNo,asset,loan);
	}

	/* 
	 * When /get/{accNo} is mapped with client request showBalance method is called at service layer
	 * In case of any exception the Controller shall take care of it using ExceptionHandlerControllerAdvice
	 */
	@GetMapping("/get/{accNo}")
	public double showBalance(@PathVariable Integer accNo)
	{
		logger.trace("Show Balance is accessed");
		return loanService.showBalance(accNo);
	}

	/* 
	 * When /calculate/{accNo}/{time} is mapped with client request calcEmi method is called at service layer
	 * In case of any exception the Controller shall take care of it using ExceptionHandlerControllerAdvice
	 */

	@GetMapping("/calculate/{accNo}/{time}")
	public Bankloan calcEmi(@PathVariable Integer accNo,@PathVariable Integer time)
	{
		logger.trace("Calculate EMI is accessed");
		return loanService.calcEmi(accNo,time);
	}

	/* 
	 * When /payEMI/{accNo} is mapped with client request payEmi method is called at service layer
	 * In case of any exception the Controller shall take care of it using ExceptionHandlerControllerAdvice
	 */

	@GetMapping("/payEMI/{accNo}")
	public Bankloan payEmi(@PathVariable Integer accNo)
	{
		logger.trace("Pay EMI is accessed");
		return loanService.payEmi(accNo);
	}

	/* 
	 * When /foreClose/{accNo} is mapped with client request foreClose method is called at service layer
	 * In case of any exception the Controller shall take care of it using ExceptionHandlerControllerAdvice
	 */

	@GetMapping("/foreClose/{accNo}")
	public Bankloan foreClose(@PathVariable Integer accNo)
	{
		logger.trace("Foreclose is accessed");
		return loanService.foreClose(accNo);
	}

	/* 
	 * When /printAll/{accNo} is mapped with client request printTransaction method is called at service layer
	 * In case of any exception the Controller shall take care of it using ExceptionHandlerControllerAdvice
	 */

	@GetMapping("/printAll/{accNo}")
	public List<Transactions> printTransaction(@PathVariable Integer accNo)
	{
		logger.trace("Print Transaction is accessed");
		return loanService.printTransaction(accNo);
	}

	/* 
	 * When /deposit/{acno2}/{amt} is mapped with client request deposit method is called at service layer
	 * In case of any exception the Controller shall take care of it using ExceptionHandlerControllerAdvice
	 */

	@GetMapping("/deposit/{acno2}/{amt}")
	public String deposit(@PathVariable Integer acno2,@PathVariable double amt)
	{
		logger.trace("Deposit is accessed");
		return loanService.deposit(acno2,amt);
	}

	/* 
	 * When /check/{uname}/{pass} is mapped with client request validate method is called at service layer
	 * In case of any exception the Controller shall take care of it using ExceptionHandlerControllerAdvice
	 */

	@GetMapping("/check/{uname}/{pass}")
	public boolean validate(@PathVariable String uname,@PathVariable String pass)
	{
		logger.trace("Validate is accessed");
		return loanService.validate(uname, pass);
	}

	/* 
	 * When /checkacc/{pass}/{accNo} is mapped with client request validateAccount method is called at service layer
	 * In case of any exception the Controller shall take care of it using ExceptionHandlerControllerAdvice
	 */

	@GetMapping("/checkacc/{pass}/{accNo}")
	public boolean validateAccount(@PathVariable String pass,@PathVariable int accNo)
	{
		logger.trace("Validate Account is accessed");
		return loanService.validateAccount(pass, accNo);
	}

	/* 
	 * When /checkDb/{e}/{ph}/{name} is mapped with client request checkDb method is called at service layer
	 * In case of any exception the Controller shall take care of it using ExceptionHandlerControllerAdvice
	 */

	@GetMapping("/checkDb/{e}/{ph}/{name}")
	public String checkDb(@PathVariable String e,@PathVariable String ph,@PathVariable String name) {
		logger.trace("Check Database is accessed");
		return loanService.checkDb(e, ph,name);
	}

}

