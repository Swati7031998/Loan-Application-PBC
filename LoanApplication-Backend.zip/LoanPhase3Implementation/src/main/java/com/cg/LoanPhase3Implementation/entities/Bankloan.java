package com.cg.LoanPhase3Implementation.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name="Bankloan")
public class Bankloan implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name="ACCOUNT_NUMBER")
	private int account_number;
	@Column(name="NAME")
	private String name;
	@Column(name="USERNAME")
	private String username;
	@Column(name="PASSWORD")
	private String password;
	@Column(name="PHONENUMBER")
	private String phonenumber;
	@Column(name="BALANCE")
	private double balance;
	@Column(name="EMAILID")
	private String emailid;
	@Column(name="LOAN_AMOUNT")
	private Double loan_amount;
	@Column(name="EMI")
	private Double emi;
	public Bankloan() {
		super();
	}   
	public Bankloan(String name,String username, String password, String phonenumber, double balance,
			String emailid,Double loan_amount,Double emi) {
		super();
		this.name=name;
		this.username = username;
		this.password = password;
		this.phonenumber = phonenumber;
		this.balance = balance;
		this.emailid = emailid;
		this.loan_amount=loan_amount;
		this.emi=emi;
	}
	
	public Double getEmi() {
		return emi;
	}
	public void setEmi(Double emi) {
		this.emi = emi;
	}
	public Double getLoan_amount() {
		return loan_amount;
	}
	public void setLoan_amount(Double loan_amount) {
		this.loan_amount = loan_amount;
	}
	public int getAccount_number() {
		return this.account_number;
	}

	public void setAccount_number(int account_number) {
		this.account_number = account_number;
	}   
	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}   
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}   
	public String getPhonenumber() {
		return this.phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}   
	public double getBalance() {
		return this.balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}   
	public String getEmailid() {
		return this.emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

}

