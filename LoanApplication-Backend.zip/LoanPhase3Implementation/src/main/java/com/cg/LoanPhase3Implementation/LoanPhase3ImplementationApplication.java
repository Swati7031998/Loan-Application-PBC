package com.cg.LoanPhase3Implementation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoanPhase3ImplementationApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoanPhase3ImplementationApplication.class, args);
	}

}
