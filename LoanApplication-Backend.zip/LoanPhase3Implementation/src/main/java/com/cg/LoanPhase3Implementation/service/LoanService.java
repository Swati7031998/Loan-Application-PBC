package com.cg.LoanPhase3Implementation.service;
import java.util.List;

import com.cg.LoanPhase3Implementation.entities.Bankloan;
import com.cg.LoanPhase3Implementation.entities.Transactions;

public interface LoanService {
	public int createAccount(Bankloan account);
	public boolean validate(String n,String p);
	public boolean validateAccount(String p, int acc);
	public String applyLoan(Integer accNo,double asset,double loan);
	public double showBalance(Integer accNo);
	public Bankloan getCust(String username,String pass);
	public Bankloan payEmi(Integer accNo);
	public String deposit(Integer acno2,double amt);
	public Bankloan foreClose(Integer accNo);
	public Bankloan calcEmi(Integer accNo,Integer time);
	public List<Transactions> printTransaction(Integer accNo);
	public String checkDb(String e,String ph,String name);
}