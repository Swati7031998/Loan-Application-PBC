package com.cg.LoanPhase3Implementation.service;
import java.util.List;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.LoanPhase3Implementation.dao.LoanDaoImpl;
import com.cg.LoanPhase3Implementation.entities.Bankloan;
import com.cg.LoanPhase3Implementation.entities.Transactions;
import com.cg.LoanPhase3Implementation.exceptions.InsufficientBalanceException;
import com.cg.LoanPhase3Implementation.exceptions.NoPendingException;
@Service
@Transactional
public class LoanServiceImpl implements LoanService {
	@Autowired
	LoanDaoImpl loan_dao;
	Logger logger=LoggerFactory.getLogger(LoanServiceImpl.class);
	/**
	 * This service method is used for creating new user account
	 * @param account This is the only parameter to createAccount method
	 * @return int This returns the generated account number after successful account creation
	 */
	@Override
	public int createAccount(Bankloan account) {
		logger.trace("Create Account is accessed at service layer");
		return loan_dao.createAccount(account);
	}
	/**
	 * This service method is used validate the username and password
	 * @param username This is the first parameter to validate method
	 * @param password This is the second parameter to validate method
	 * @return boolean This returns true if the username and password are valid
	 */
	@Override
	public boolean validate(String username, String password) {
		logger.trace("Validate method is accessed at service layer");
		return loan_dao.validate(username, password);
	}
	/**
	 * This service method is used for validation of account number
	 * @param password This is the first parameter to validateAccount method
	 * @param account_number This is the second parameter to validateAccount method
	 * @return boolean This returns true if the account number entered by the user matches the account number for that password
	 */
	@Override
	public boolean validateAccount(String password, int account_number) {
		logger.trace("Validate Account is accessed at service layer");
		return loan_dao.validateAccount(password, account_number);
	}
	/**
	 * This service method is used to apply for loan
	 * @param account_number This is the first parameter to applyLoan method
	 * @param asset This is the second paramter to applyLoan method
	 * @param loan This is the third paramter to applyLoan method
	 * @return String This returns string value "OK" if the user is qualified to apply for loan
	 */
	@Override
	public String applyLoan(Integer account_number,double asset,double loan){
		logger.trace("Apply Loan is accessed at service layer");
		return loan_dao.applyLoan(account_number,asset,loan);

	}
	/**
	 * This service method is used to show the existing account balance
	 * @param accNo This is the only paramter to showBalance method
	 * @return double This returns the existing account balance
	 */
	@Override
	public double showBalance(Integer accNo) {
		logger.trace("Show Balance is accessed at service layer");
		return loan_dao.showBalance(accNo);
	}

	/**
	 * This service method is used to get the Customer details for the corresponding username and password
	 * @param username This is the first parameter to getCust method
	 * @param password This is the second parameter to getCust method
	 * @return Bankloan This returns the object matching the given username and password
	 */
	@Override
	public Bankloan getCust(String username, String password) {
		logger.trace("Get Customer is accessed at service layer");
		return loan_dao.getCust(username, password);
	}

	/**
	 * This service method is used to pay Equated Monthly Installments(EMI)
	 * @param accNo This is the only parameter to payEmi method
	 * @return Bankloan This is returned after the changes are made to the Bankloan object
	 * @throws InsufficientBalanceException This exception is thrown if the account balance is not sufficient to pay the EMI
	 */
	@Override
	public Bankloan payEmi(Integer accNo)throws InsufficientBalanceException{
		logger.trace("Pay EMI is accessed at service layer");
		Bankloan bank=loan_dao.getCustbyaccount(accNo);
		if(bank.getLoan_amount()==0.0) {
			return bank;
		}
		if(bank.getEmi()<=bank.getLoan_amount() && bank.getEmi()<=bank.getBalance())
		{
			logger.info("EMI payment successful");
			double loan_amount =bank.getLoan_amount()-bank.getEmi();
			double balance =bank.getBalance()-bank.getEmi();
			bank.setBalance(balance);
			bank.setLoan_amount(loan_amount);
			return loan_dao.payEmi(bank);
		}
		else
		{
			logger.error("InsufficientBalanceException thrown by PayEmi method");
			throw new InsufficientBalanceException("Insufficient account Balance");
		}
	}

	/**
	 * This service method is used to deposit balance into the given account number
	 * @param account_number This is the first paramter to deposit method
	 * @param deposit_amount This is the second paramter to deposit method
	 * @return String This returns custom String message after successful deposit
	 */
	@Override
	public String deposit(Integer account_number,double deposit_amount) {
		logger.trace("Deposit is accessed at service layer");
		return loan_dao.deposit(account_number,deposit_amount);
	}

	/**
	 * This service method is used for foreclose
	 * @param accNo This is the only parameter to foreClose method
	 * @return Bankloan This is returned after the changes are made to the Bankloan object
	 * @throws NoPendingException This exception is thrown if there are no pending loans against the given account number
	 */
	@Override
	public Bankloan foreClose(Integer accNo)throws NoPendingException{
		logger.trace("Foreclose is accessed at service layer");
		Bankloan bank=loan_dao.getCustbyaccount(accNo);
		if(bank.getLoan_amount()==0.0) {
			logger.error("NoPendingException thrown by foreClose method");
			throw new NoPendingException("No Pending loans on this account");
		}
		if(bank.getBalance()>=bank.getLoan_amount())
		{
			double balance_value = bank.getBalance()-bank.getLoan_amount();
			bank.setBalance(balance_value);
			return loan_dao.foreClose(bank);
		}
		else
		{
			bank.setLoan_amount(0.0);
			return loan_dao.foreClose(bank);
		}	

	}

	/**This service method is used to calculate the Equated Monthly Installments(EMI)
	 * @param accNo This is the first parameter to calcEmi method
	 * @param time This is the second parameter to calcEmi method
	 * @return Bankloan This is returned after the changes are made to the Bankloan
	 * @throws NoPendingException This exception is thrown if there are no pending loans against the given account number
	 */
	@Override
	public Bankloan calcEmi(Integer accNo,Integer time)throws NoPendingException{
		logger.trace("Calculate EMI is accessed at service layer");
		Bankloan bank=loan_dao.getCustbyaccount(accNo);
		if(bank.getLoan_amount()==0.0) {
			logger.error("NoPendingException thrown by calcEmi method");
			throw new NoPendingException("No pending loans on this account");
		}
		else {
			logger.info("EMI calculation successful");
			double loan_amount=bank.getLoan_amount();
			double emi = Math.ceil((loan_amount+(loan_amount*7*time)/100)/(time*12));
			bank.setEmi(emi);
			return loan_dao.calcEmi(bank);
		}
	}

	/**
	 * This service method is used to get the transactions against a given account number
	 * @param accNo This is the only paramter to printTransaction method
	 * @return List<Transactions> This returns the list of transaction aginst a given account number
	 */
	@Override
	public List<Transactions> printTransaction(Integer accNo) {
		logger.trace("Print Transaction is accessed at service layer");
		return loan_dao.printTransaction(accNo);
	}

	/**
	 * This service method is used to check whether the details entered by the user during sign up already exist
	 * @param email_id This is the first parameter to checkDb method
	 * @param phone_number This is the second parameter to checkDb method
	 * @param username This is the third parameter to checkDb method
	 * @return String This returns a String value "OK" if the record does not exist
	 */
	@Override
	public String checkDb(String email_id,String phone_number,String username) {
		logger.trace("Check Database is accessed at service layer");
		return loan_dao.checkDb(email_id,phone_number,username);
	}

}

