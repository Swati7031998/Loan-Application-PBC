package com.cg.LoanPhase3Implementation;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import com.cg.LoanPhase3Implementation.exceptions.InsufficientBalanceException;
import com.cg.LoanPhase3Implementation.exceptions.InvalidAccountException;
import com.cg.LoanPhase3Implementation.exceptions.InvalidLoginException;
import com.cg.LoanPhase3Implementation.exceptions.NoPendingException;
import com.cg.LoanPhase3Implementation.exceptions.UserAlreadyExistsException;

@ControllerAdvice
public class ExceptionHandlerControllerAdvice {
	@ExceptionHandler(value= {UserAlreadyExistsException.class,InvalidLoginException.class,
			InvalidAccountException.class,InsufficientBalanceException.class,NoPendingException.class})
	public final ResponseEntity<String> exceptionHandler(Exception e){
		return new ResponseEntity<>(e.getMessage(),HttpStatus.BAD_REQUEST);
	}
}

