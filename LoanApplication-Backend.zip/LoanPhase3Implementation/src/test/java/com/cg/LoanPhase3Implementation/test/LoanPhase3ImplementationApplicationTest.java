package com.cg.LoanPhase3Implementation.test;
import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;
import org.junit.runner.RunWith;
import javax.transaction.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.junit4.SpringRunner;
import com.cg.LoanPhase3Implementation.entities.Bankloan;
import com.cg.LoanPhase3Implementation.service.LoanServiceImpl;

@RunWith(SpringRunner.class)
@Transactional
@SpringBootTest
public class LoanPhase3ImplementationApplicationTest {
	@Autowired 
	private LoanServiceImpl loanService;
	Logger logger=LoggerFactory.getLogger(LoanPhase3ImplementationApplicationTest.class);

	@Test
	@Rollback(true)
	public void createAccountTest() {
		logger.trace("createAccountTest accessed");
		Bankloan account=new Bankloan();
		account.setName("Sample");
		account.setUsername("sample123");
		account.setEmailid("sample@gmail.com");
		account.setPhonenumber("9876543210");
		account.setPassword("S@mple123");
		account.setEmi(0.0);
		account.setBalance(200000);
		account.setLoan_amount(0.0);
		int account_number=loanService.createAccount(account);
		logger.info("Sample account created");
		Bankloan sample_account=loanService.getCust(account.getUsername(), account.getPassword());
		assertThat(account.getName()).isEqualTo(sample_account.getName());
		assertThat(account.getAccount_number()).isEqualTo(sample_account.getAccount_number());
		assertThat(account.getEmailid()).isEqualTo(sample_account.getEmailid());
		assertThat(account.getBalance()).isEqualTo(sample_account.getBalance());
		assertThat(account.getPhonenumber()).isEqualTo(sample_account.getPhonenumber());
		assertThat(account.getEmi()).isEqualTo(sample_account.getEmi());
		assertThat(account.getLoan_amount()).isEqualTo(sample_account.getLoan_amount());
	}

	@Test
	@Rollback(true)
	public void validateTest() throws Exception{
		logger.trace("validateTest Accessed");
		Bankloan account=new Bankloan();
		account.setName("Sample");
		account.setUsername("sample123");
		account.setEmailid("sample@gmail.com");
		account.setPhonenumber("9876543210");
		account.setPassword("S@mple123");
		account.setEmi(0.0);
		account.setBalance(200000);
		account.setLoan_amount(0.0);

		int account_number=loanService.createAccount(account);
		logger.info("Sample account created");
		boolean check=false;
		String message=null;
		try {
			check=loanService.validate(account.getUsername(),account.getPassword());
		}
		catch(Exception e) {
			message=e.getMessage();
		}
		assertThat(true).isEqualTo(check);

		//------------------------------------------------------//
		try {
			check=loanService.validate("Swati7",account.getPassword());
		}
		catch(Exception e) {
			message=e.getMessage();
		}
		assertThat("Account does not exist").isEqualTo(message);
	}
	
	@Test
	@Rollback(true)
	public void validateAccountTest() throws Exception{
		logger.trace("validateAccountTest Accessed");
		Bankloan account=new Bankloan();
		account.setName("Sample");
		account.setUsername("sample123");
		account.setEmailid("sample@gmail.com");
		account.setPhonenumber("9876543210");
		account.setPassword("S@mple123");
		account.setEmi(0.0);
		account.setBalance(200000);
		account.setLoan_amount(0.0);

		int account_number=loanService.createAccount(account);
		logger.info("Sample account created");
		boolean check=false;
		String message=null;
		try {
			check=loanService.validateAccount(account.getPassword(),account.getAccount_number());
		}
		catch(Exception e) {
			message=e.getMessage();
		}
		assertThat(true).isEqualTo(check);
		//------------------------------------------------//
		try {
			check=loanService.validateAccount(account.getPassword(),1003);
		}
		catch(Exception e) {
			message=e.getMessage();
		}
		assertThat("Sorry!Account does not exist!!").isEqualTo(message);
		
	}
	@Test
	@Rollback(true)
	public void payEmiTest() {
		logger.info("validateAccountTest Accessed");
		Bankloan account=new Bankloan();
		account.setName("Sample");
		account.setUsername("sample123");
		account.setEmailid("sample@gmail.com");
		account.setPhonenumber("9876543210");
		account.setPassword("S@mple123");
		account.setBalance(200000);
		account.setLoan_amount(0.0);
		int account_number=loanService.createAccount(account);
		String msg1=loanService.applyLoan(account_number, 500000, 100000);
		account.setEmi(loanService.calcEmi(account_number, 4).getEmi());
		logger.info("Sample account created");
		Bankloan retrieved_account=new Bankloan();
		retrieved_account=loanService.payEmi(account_number);
		assertThat(account.getBalance()).isEqualTo(retrieved_account.getBalance()+account.getEmi());
	}
	
	@Test
	@Rollback(true)
	public void showBalanceTest() {
		logger.info("showBalanceTest accessed");
		Bankloan account=new Bankloan();
		account.setName("Sample");
		account.setUsername("sample123");
		account.setEmailid("sample@gmail.com");
		account.setPhonenumber("9876543210");
		account.setPassword("S@mple123");
		account.setBalance(200000);
		account.setLoan_amount(0.0);
		int account_number=loanService.createAccount(account);
		logger.info("Sample account created");
		assertThat(account.getBalance()).isEqualTo(loanService.showBalance(account_number));
	}
	
	@Test
	@Rollback(true)
	public void depositTest() {
		logger.info("depositTest accessed");
		Bankloan account=new Bankloan();
		account.setName("Sample");
		account.setUsername("sample123");
		account.setEmailid("sample@gmail.com");
		account.setPhonenumber("9876543210");
		account.setPassword("S@mple123");
		account.setBalance(200000);
		account.setLoan_amount(0.0);
		int account_number=loanService.createAccount(account);
		logger.info("Sample account created");
		String message=null;
		double deposit_amount=200.0;
		message=loanService.deposit(account_number, deposit_amount);
		assertThat("The amount "+deposit_amount+" is successfully added to your acount!!").isEqualTo(message);
	}
	
	@Test
	@Rollback(true)
	public void forecloseTest() throws Exception{
		logger.info("forecloseTest accessed");
		Bankloan account=new Bankloan();
		account.setName("Sample");
		account.setUsername("sample123");
		account.setEmailid("sample@gmail.com");
		account.setPhonenumber("9876543210");
		account.setPassword("S@mple123");
		account.setBalance(300000.0);
		account.setLoan_amount(0.0);
		double loan=account.getLoan_amount();
		int account_number=loanService.createAccount(account);
		String msg1=loanService.applyLoan(account_number, 500000, 100000);
		logger.info("Sample account created");
		String check=null;
		Bankloan retrieved_account=new Bankloan();
		try {
			retrieved_account=loanService.foreClose(account_number);
		}
		catch(Exception e) {
			check=e.getMessage();
		}
		assertThat(0.0).isEqualTo(retrieved_account.getLoan_amount());
		if(account.getBalance()>=account.getLoan_amount())
			assertThat((account.getBalance()-loan)).isEqualTo(retrieved_account.getBalance());
		//--------------------------------------------------------//
		try {
			retrieved_account=loanService.foreClose(account_number);
		}
		catch(Exception e) {
			check=e.getMessage();
		}
			assertThat("No Pending loans on this account").isEqualTo(check);
	}
	
	@Test
	@Rollback(true)
	public void checkDbTest() throws Exception {
		logger.info("checkDbTest accessed");
		Bankloan account=new Bankloan();
		account.setName("Sample");
		account.setUsername("sample123");
		account.setEmailid("sample@gmail.com");
		account.setPhonenumber("9876343210");
		account.setPassword("S@mple1203");
		account.setBalance(300000.0);
		account.setLoan_amount(0.0);
		logger.info("Sample account ");
		String message=null;
		String messages=null;
		try {
			message=loanService.checkDb(account.getEmailid(),account.getPhonenumber(), account.getUsername());
		}
		catch(Exception e) {
			messages=e.getMessage();
		}
		assertThat("OK").isEqualTo(message);
		int account_number=loanService.createAccount(account);
		Bankloan account11=new Bankloan();
		account11.setName("Sample1235");
		account11.setUsername("sample123");
		account11.setEmailid("sample4321@gmail.com");
		account11.setPhonenumber("9876540710");
		account11.setPassword("S@mple4321");
		account11.setBalance(300000.0);
		account11.setLoan_amount(0.0);
		logger.info("Another Sample account created");
		String message1=null;
		String messages1=null;
		try {
			message1=loanService.checkDb(account11.getEmailid(),account11.getPhonenumber(), account11.getUsername());
		}
		catch(Exception e) {
			messages1=e.getMessage();
		}
		assertThat("User name exists").isEqualTo(messages1);
		Bankloan account2=new Bankloan();
		account2.setName("Sample1234");
		account2.setUsername("sample14");
		account2.setEmailid("sample@gmail.com");
		account2.setPhonenumber("9076543710");
		account2.setPassword("S@mple1234");
		account2.setBalance(300000.0);
		account2.setLoan_amount(0.0);
		String message3=null;
		String messages3=null;
		try {
			message3=loanService.checkDb(account2.getEmailid(),account2.getPhonenumber(), account2.getUsername());
		}
		catch(Exception e) {
			messages3=e.getMessage();
		}
		assertThat("You already have an account!Please kindly login!!").isEqualTo(messages3);
	}

}
